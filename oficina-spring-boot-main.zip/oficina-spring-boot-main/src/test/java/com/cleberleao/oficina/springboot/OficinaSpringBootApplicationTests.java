package com.cleberleao.oficina.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OficinaSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
